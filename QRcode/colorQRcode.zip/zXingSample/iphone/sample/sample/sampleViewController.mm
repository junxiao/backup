//
//  sampleViewController.m
//  sample
//
//  Created by Mujtaba Mehdi on 9/15/11.
//  Copyright 2011 http://www.codesignerror.com All rights reserved.
//

#import "sampleViewController.h"
#import "QRCodeReader.h"

@implementation sampleViewController
@synthesize resultLbl;
@synthesize textLbl;

- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (IBAction)scanPressed:(id)sender {
    
    ZXingWidgetController *widController = [[[ZXingWidgetController alloc] initWithDelegate:self showCancel:YES OneDMode:NO] autorelease];
    QRCodeReader* qrcodeReader = [[[QRCodeReader alloc] init] autorelease];
    NSSet *readers = [[NSSet alloc ] initWithObjects:qrcodeReader,nil];
    widController.readers = readers;
    [readers release];
    [self presentModalViewController:widController animated:YES];
    counter = 0;
}

#pragma mark -
#pragma mark ZXingDelegateMethods

- (void)zxingController:(ZXingWidgetController*)controller didScanResult:(NSString *)result {
    [self dismissModalViewControllerAnimated:NO];
    
    NSString *str1 = @"GVOA45FYCI6M8-*%D*P5G RC9:C95ACA63RCG PMP2COH";    
    NSString *str2 = @"GVOAD5EYFF6M8-%6%UP5G 599:C956S34-RZ%KU6P*CG%";    
    NSString *str3 = @"GS6C45EYCIEM80F%D2RIG P9638958SAH-RBG PMP2CGE";  
    
    counter ++;
    
    if ([result length]>0) {
        [resultLbl setText:result];
   //     NSLog(@"create string: %d, %@",  counter, result);       
        if(counter == 1)
        {
            [textLbl setText:@"No Match"];
        }

  //          NSLog(@"create string: %d, %@",  counter, result);
        int d1= [self compareDistance:result withString:str1];
        int d2= [self compareDistance:result withString:str2];
        int d3= [self compareDistance:result withString:str3];
        NSLog(@"compare string: %d, %d, %d\n",  d1, d2, d3);
        int min = d1;
        if ( d2 < min )
        {
            min = d2;
        }
        if( d3 < min )
        {
            min = d3;
        }
//        NSLog(@"min distance: %d\n",  min);
        if(min == -1)
        {
            [textLbl setText:@"No Match"];
           
        }
        else
        {
            if (min == d1)
            {
                [textLbl setText:@"demo1"];
            }
            if (min == d2)
            {
                [textLbl setText:@"demo2"];
            }
            if (min == d3)
            {
                [textLbl setText:@"demo3"];
            }
        }
        
        
    }
    else {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:nil message:NSLocalizedString(@" Not valid bar code for this Application", @"") delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        [alertView show];
        [alertView release];
    }
}
// return the minimum of a, b and c
- (int) smallestOf: (int) a andOf: (int) b andOf: (int) c
{
    int min = a;
    if ( b < min )
        min = b;
    
    if( c < min )
        min = c;
    
    return min;
}

- (int) compareLevenshteinDistance: (NSString *) stringA withString:(NSString *) stringB
{    
    
    // Step 1
    int k, i, j, cost, * d, distance;
    
    int n = [stringA length];
    int m = [stringB length];	
    
    if( n++ != 0 && m++ != 0 ) {
        
        d = (int *) malloc( sizeof(int) * m * n );
        
        // Step 2
        for( k = 0; k < n; k++)
            d[k] = k;
        
        for( k = 0; k < m; k++)
            d[ k * n ] = k;
        
        // Step 3 and 4
        for( i = 1; i < n; i++ )
            for( j = 1; j < m; j++ ) {
                
                // Step 5
                if( [stringA characterAtIndex: i-1] == 
                   [stringB characterAtIndex: j-1] )
                    cost = 0;
                else
                    cost = 1;
                
                // Step 6
                d[ j * n + i ] = [self smallestOf: d [ (j - 1) * n + i ] + 1
                                            andOf: d[ j * n + i - 1 ] +  1
                                            andOf: d[ (j - 1) * n + i -1 ] + cost ];
            }
        
        distance = d[ n * m - 1 ];
        
        free( d );
        
        return distance;
    }
    return 0;
}

- (int) compareDistance: (NSString *) stringA withString:(NSString *) stringB
{    
    
    // Step 1
    int distance = 0;
    
    int n = [stringA length];
    int m = [stringB length];	
    if (n!=m) return -1;
          for( int i = 0; i < n; i++ )
          {
                if( [stringA characterAtIndex: i] != 
                   [stringB characterAtIndex: i] )
                    distance ++;
          }
        return distance;
}



- (void)zxingControllerDidCancel:(ZXingWidgetController*)controller {
    [self dismissModalViewControllerAnimated:YES];
    
}

#pragma mark - View lifecycle

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
}
*/

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
