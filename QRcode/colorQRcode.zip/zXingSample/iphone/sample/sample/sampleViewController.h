//
//  sampleViewController.h
//  sample
//
//  Created by Mujtaba Mehdi on 9/15/11.
//  Copyright 2011 http://www.codesignerror.com All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZXingWidgetController.h"

@interface sampleViewController : UIViewController<ZXingDelegate> {
    IBOutlet UILabel *resultLbl;
    IBOutlet UILabel *textLbl;
    int counter;
}
@property(nonatomic,retain) IBOutlet UILabel *resultLbl;
@property(nonatomic,retain) IBOutlet UILabel *textLbl;
- (IBAction)scanPressed:(id)sender;
- (int) compareDistance: (NSString *) stringA withString:(NSString *) stringB;
@end