﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace _3DUI
{
    public partial class Form2 : Form
    {
        float headx;
        float heady;
        float headz;

        public double distance;
        public double deltax;
        public double deltaz;

        public Form2()
        {
            InitializeComponent();
        }

 /*       private void FormImage_Load(object sender, EventArgs e)
        {
            int frm_width = this.Width;
            int frm_height = this.Height;

            //Get the Width and Height (resolution) of the screen
            System.Windows.Forms.Screen src = System.Windows.Forms.Screen.PrimaryScreen;
            int src_height = src.Bounds.Height;
            int src_width = src.Bounds.Width;

            //put the form in the center
            this.Left = (src_width - frm_width) / 2;
            this.Top = (src_height - frm_height)/2;
        }
        */

        public void showLable()
        {
            label1.Visible = true;
        }
        public void SetValue(float x, float y, float z)
        {
            headx = x;
            heady = y;
            headz = z;
            if (label1.Visible)
            {
                string s1 = x.ToString();
                string s2 = y.ToString();
                string s3 = z.ToString();
                string s = "x: " + s1 + " z: " + s3;
                label1.Text = s;
            }
            Invalidate();

        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Brush red = new SolidBrush(Color.Red);
/*            int r = Convert.ToInt32(((headz-distance) * (headz-distance)) * 100 * 5);
            if (r < 10) r = 10;
            if (r > 50) r = 50;
            if (headx > deltax || headx < -deltax || headz > (distance + deltaz) || headz < (distance - deltaz))
            {
                g.FillEllipse(red, this.Width / 2 + headx * 400, (this.Height) / 2, r, r);
            }  */
            int r = 20;
            int y = Convert.ToInt32((headz - distance) * 100);
            if (y < -50) y = -50;
            if (y > 50) y = 50;
            if (headx > deltax || headx < -deltax || headz > (distance + deltaz) || headz < (distance - deltaz))
            {
                g.FillEllipse(red, this.Width / 2 + headx * 400, this.Height / 2 - y, r, r);
                this.pictureBox1.Visible = true;
            }
            else
            {
                this.pictureBox1.Visible = false;
            }
            base.OnPaint(e);
        }

    }
}
