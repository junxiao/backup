﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.Kinect;

namespace _3DUI
{
    public partial class Form3DUI : Form
    {
        public KinectSensor kinectSensor;
        Form2 formImage;
        private Skeleton[] skeletonData;
        float headX;
        float headY;
        float headZ;
  
        public Form3DUI()
        {
            InitializeComponent();
            foreach (KinectSensor kinect in KinectSensor.KinectSensors)
            {
                kinectSensor = kinect;
            }
            kinectSensor.DepthStream.Enable(DepthImageFormat.Resolution320x240Fps30);
            this.kinectSensor.SkeletonStream.AppChoosesSkeletons = true;
            kinectSensor.SkeletonStream.Enable();
        }

        private void KinectAllFramesReady(object sender, AllFramesReadyEventArgs e)
        {
            // Have we already been "shut down" by the user of this viewer, 
            // or has the SkeletonStream been disabled since this event was posted?
            if ((this.kinectSensor == null) || !((KinectSensor)sender).SkeletonStream.IsEnabled)
            {
                return;
            }

            bool haveSkeletonData = false;

            using (SkeletonFrame skeletonFrame = e.OpenSkeletonFrame())
            {
                if (skeletonFrame != null)
                {
                    if (this.formImage == null)
                    {
                        return;
                    }

                    if ((this.skeletonData == null) || (this.skeletonData.Length != skeletonFrame.SkeletonArrayLength))
                    {
                        this.skeletonData = new Skeleton[skeletonFrame.SkeletonArrayLength];
                    }

                    skeletonFrame.CopySkeletonDataTo(this.skeletonData);

                    haveSkeletonData = true;
                }
            }

            if (haveSkeletonData)
            {
                using (DepthImageFrame depthImageFrame = e.OpenDepthImageFrame())
                {
                    if (depthImageFrame != null) 
                    {
 
                        foreach (Skeleton skeleton in this.skeletonData)
                        {
                            // Transform the data into the correct space
                            // For each joint, we determine the exact X/Y coordinates for the target view
                            if (skeleton.TrackingState == SkeletonTrackingState.Tracked)
                            {
                                Joint head = skeleton.Joints[JointType.Head];
                                if (head.TrackingState == JointTrackingState.Tracked)
                                {
                                    headX = head.Position.X;
                                    headY = head.Position.Y;
                                    headZ = head.Position.Z;
                                    System.Diagnostics.Debug.WriteLine("x:{0:F}", headX);
                                    System.Diagnostics.Debug.WriteLine("y:{0:F}", headY);
                                    System.Diagnostics.Debug.WriteLine("z:{0:F}", headZ);
                                    if (formImage != null) formImage.SetValue(headX, headY, headZ);
                                 }
                            }
                         }
                        this.ChooseClosestSkeletons(this.skeletonData, 1);

                    }
                 }
            }
        }

        private void ChooseClosestSkeletons(IEnumerable<Skeleton> skeletonDataValue, int count)
        {
            SortedList<float, int> depthSorted = new SortedList<float, int>();

            foreach (Skeleton s in skeletonDataValue)
            {
                if (s.TrackingState != SkeletonTrackingState.NotTracked)
                {
                    float valueZ = s.Position.Z;
                    while (depthSorted.ContainsKey(valueZ))
                    {
                        valueZ += 0.0001f;
                    }

                    depthSorted.Add(valueZ, s.TrackingId);
                }
            }

            this.ChooseSkeletonsFromList(depthSorted.Values, count);
        }

        private void ChooseSkeletonsFromList(IList<int> list, int max)
        {
            if (this.kinectSensor.SkeletonStream.IsEnabled)
            {
                int argCount = Math.Min(list.Count, max);

                if (argCount == 0)
                {
                    this.kinectSensor.SkeletonStream.ChooseSkeletons();
                }

                if (argCount == 1)
                {
                    this.kinectSensor.SkeletonStream.ChooseSkeletons(list[0]);
                }

                if (argCount >= 2)
                {
                    this.kinectSensor.SkeletonStream.ChooseSkeletons(list[0], list[1]);
                }
            }
        }



        private void button1_Click(object sender, EventArgs e)
        {
            kinectSensor.Start();
            kinectSensor.AllFramesReady += new EventHandler<AllFramesReadyEventArgs>(KinectAllFramesReady);
            if ((formImage == null) || (formImage.IsDisposed))
            {
                formImage = new Form2();
                formImage.Show();
                formImage.SetValue(headX, headY, headZ);
            }
            this.WindowState = System.Windows.Forms.FormWindowState.Minimized;
            formImage.deltax = Convert.ToDouble(this.numericUpDown1.Value);
            formImage.deltaz = Convert.ToDouble(this.numericUpDown2.Value);
            formImage.distance = Convert.ToDouble(this.numericUpDown3.Value);
            if (checkBox1.Checked)
            {
                formImage.showLable();
            }
            formImage.Focus();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
